from .employee_base import EmployeeBase

class Caretaker(EmployeeBase):
    pass