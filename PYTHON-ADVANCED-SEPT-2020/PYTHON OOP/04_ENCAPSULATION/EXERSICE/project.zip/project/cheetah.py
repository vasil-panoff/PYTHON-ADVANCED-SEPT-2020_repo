from .animal_base import AnimalBase

class Cheetah(AnimalBase):
    needs = 60